# c2c-bank-app
This is a python app that lets users check the balance on their loans and do other functions related to their bank account.

This is used for week 3 lessons in conditionals, booleans, control flow, and functions.
